# Mall-Segmentation
Busniess Context: We have data of customers of supermarket mall and their membership details like Customer ID, age, gender, annual income and spending score.

Malls or shopping complexes are often indulged in the race to increase their customers and hence making huge profits. To achieve this task machine learning is being applied by many stores already.
It is amazing to realize the fact that how machine learning can aid in such ambitions. The shopping complexes makes use of their customers’ data and develop ML models in order to target the right ones. This not only increases the sales but also makes the complexes efficient.

<b>Problem Statement</b>: To understand the customers like who can be easily converge to spend more. Target: So the sense can be given to marketing team and plan the strategy accordingly. 
